		</div><!-- /container-->
	</div><!-- /wrapper -->
	<div id="footer">
		<span class="floatLeft"><a href="<?= WEB_URL; ?>" title="Copyright &copy; <?php echo date("Y"); ?> <?= BUSINESS ?>">Copyright &copy; <?php echo date("Y"); ?> <?= BUSINESS ?></a></span>
		<span class="floatRight"><a href="http://www.navigatormm.com" title="Kelowna Web Design and Hosting by Navigator Multimedia Inc" accesskey="n" target="_blank">Kelowna Web Design and Hosting by Navigator Multimedia Inc</a></span>
	</div><!-- /footer -->