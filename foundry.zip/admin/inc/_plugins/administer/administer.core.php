<?php
// ADMINISTER
//
// Author: Chris Donalds <chrisd@navigatormm.com>
// Date: September 3, 2010
// Version: 3.0
// License: GPL
// ----------------------------------------------
// Prepares and handles frontend-to-admin system interfacing

function prepAdminister(){
	print<<<EOT
	<span id="adm_label">Click to Administer</span>
EOT;
}
?>
