<?php
/*
MY PLUG-IN
Web Template 3.0
Chris Donalds <chrisd@navigatormm.com>
========================================
*/

function myplugin2_headerprep(){
}

function showMyPlugin2(){
    echo "HELLO 2";
}

?>