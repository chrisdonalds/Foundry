<?php
	// ---------------------------
	//
	// PUBLIC SITE CUSTOM FUNCTIONS
	// - Here the developer may create custom or one-time only functions that will be
	// incorporated into the website system automatically
	//
	// ---------------------------

if(!defined("VALID_LOAD")) die("This file cannot be accessed directly!");

// Add functions below this line //


?>