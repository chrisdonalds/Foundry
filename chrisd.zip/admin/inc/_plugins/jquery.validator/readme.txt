FORM VALIDATOR - JQUERY
Web Template 3.0
Chris Donalds <chrisd@navigatormm.com>
========================================

-- Inclusions --
validator                       ... validates all forms on page
validator(form1[, form2...])    ... validates specific forms (comma-separated by id) on page

-- Implementation --
see readme.txt in root