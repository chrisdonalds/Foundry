<p>
	<label for="tubepress-widget-title"><?php echo ${org_tubepress_template_Template::WIDGET_CONTROL_TITLE}; ?><input class="widefat" id="tubepress-widget-title" name="tubepress-widget-title" type="text" value="<?php echo ${org_tubepress_template_Template::WIDGET_TITLE}; ?>" /></label>
</p>
<p>
	<label for="tubepress-widget-tagstring"><?php echo ${org_tubepress_template_Template::WIDGET_CONTROL_SHORTCODE}; ?>
		<textarea class="widefat" rows="9" cols="12" id="tubepress-widget-tagstring" name="tubepress-widget-tagstring"><?php echo ${org_tubepress_template_Template::WIDGET_SHORTCODE}; ?></textarea>
	</label>
</p>
<input type="hidden" id="tubepress-widget-submit" name="tubepress-widget-submit" value="1" />