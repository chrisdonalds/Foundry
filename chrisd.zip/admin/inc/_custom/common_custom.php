<?php
	// ---------------------------
	//
	// ADMIN AREA COMMON FUNCTIONS
	//  - CUSTOM -
	//
	// ---------------------------
	//
 	// list of tool functions
	// - Uses: MySQL 4.2+

define ("ADMINCUSTOM", true);

if(!defined("VALID_LOAD")) die ("This file cannot be accessed directly!");

// ----------- CUSTOM FUNCTIONS ---------------


?>