More RSS display files can be added by using this...

 - addHeadLine("rss", WEB_URL.RSS_FOLDER, "show{...}rss.php", BUSINESS." feed name"); 

Sample use of Add Head Plugin and Lines

 - addHeadLine("favicon", WEB_URL.IMG_UPLOAD_FOLDER, "favicon.ico", "");
 - addHeadLine("style", WEB_URL.CSS_FOLDER, "stylesheet.css", "all, screen, or print");
 
