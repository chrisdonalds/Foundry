-- 

Make sure:

1. CKEDitor Userfiles folder and sub-folders are CHMODed to 755 (Full Control in Windows)
2. Edit configs.php with correct website, database, record-keeping, and section settings

Preinstalled plug-ins/features:

- JQuery 1.3.2
- Lightbox
- Thickbox
- ShowCalendar for JSCal2
- SWFObject for Flash
- Captcha
- CDCal
- FormToEmailPro
- RSS Creator
- CSSConst (CSS Variables)