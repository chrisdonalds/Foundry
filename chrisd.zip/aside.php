<?php 
/*
Title:			Generic/Dynamic Page
Author: 		Chris Satterthwaite, Chris Donalds
Updated: 		May.18.2010
Updated By: 	Chris Satterthwaite, Chris Donalds
 */
?>
	<div id="news-aside">
        <h4>Whats New 02</h4>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sapien nibh, egestas et mattis non, dictum luctus nulla.</p>
        <a class="button black small floatRight" href="" title="Read More">Read More</a>

        <h4 class="clear">Whats New 03</h4>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sapien nibh, egestas et mattis non, dictum luctus nulla.</p>
        <a class="button black small floatRight" href="" title="Read More">Read More</a>

        <h4 class="clear">Whats New 04</h4>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sapien nibh, egestas et mattis non, dictum luctus nulla.</p>
        <a class="button black small floatRight" href="" title="Read More">Read More</a>
    </div>
